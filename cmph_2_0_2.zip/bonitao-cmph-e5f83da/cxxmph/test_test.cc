#include "test.h"

bool tautology() { return true; }
CXXMPH_TEST_CASE(tautology)
